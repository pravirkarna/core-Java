package coreJavaBatch;

public abstract class abstractDemo3 {

}
