package coreJavaBatch;

public class UserDetails {

	public static void main(String[] args) {
		
		
		encapsulation encaps = new encapsulation();
		encaps.setname("Naveen");
		encaps.setage(35);
		
		System.out.println("My name is " +encaps.getname());
		System.out.println("My age is " +encaps.getage());
		
		System.out.println("My Address is " +encaps.getaddress());
		
		
	
		
		

	}

}
