package coreJavaBatch;

public class grandfather {
	
	public   void abc () {
		System.out.println("i am into Grandfather class");
		
		
	}
	
	public  static void abcd() {
		
		System.out.println("i am in Grandfather class");
		
	}
	

}
