package coreJavaBatch;

public interface bankRbi {
	
	int a=12;
	 int b=10;
	//abstract method
	public int ROI(int a);
	public void savingaccount();
	public void current();
	
	public void details();//different method than in bank interface
	
	
	

}


