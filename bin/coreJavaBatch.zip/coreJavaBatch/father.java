package coreJavaBatch;

public class father extends grandfather {
	
	
public void print() {
	System.out.println("I am in father class");
}

public void display() {
	System.out.println("I am in father class");
}

public void run() {
	System.out.println("I am in father class");
}

public   void abc () {
	System.out.println("father :i am into father class");
	
}	
	
	
	
}
