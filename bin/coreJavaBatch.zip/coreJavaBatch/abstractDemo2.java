package coreJavaBatch;

public abstract class abstractDemo2 {
	
	public abstract void naveen();
	public abstract void sydney();
	public abstract void australia();
	
	//simple
	
	public  void india() {
		System.out.println("I am in abstract class 2");
	}

}
