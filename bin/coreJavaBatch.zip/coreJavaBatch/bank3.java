package coreJavaBatch;

public interface bank3 {
	
	public int ROI(int a);
	public void savingaccount();
	public void current();
	public void address();//different
	

}
