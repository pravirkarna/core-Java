package coreJavaBatch;

public class user {
	

	public static void main(String[] args) {
		
		
	
				
		
		hdfcbank hdfc = new hdfcbank();
		System.out.println(hdfc.ROI(15));
		
		
		icicibank icici = new icicibank();
		icici.ROI(12);
		
		
		

	}
	
	

}
