package coreJavaBatch;

public  class overriding {

	public  final void rate() {
		System.out.println("rate is 7 %");
	}
	
	public void print() {
		System.out.println("I am into parent");
	}
	
	public int add (int a,int b) {
		 System.out.println("parent");
		return a+b;
	}
	
}
