package coreJavaBatch;

public  class hdfcbank implements bank,bankRbi{

	  
	@Override
	public int ROI(int a ) {
		System.out.println("hdfc : ROI 7%");
		return a;
		
	}

	@Override
	public void savingaccount() {
		
		
		
	}

	@Override
	public void current() {
		
		
	}

	@Override
	public void rate() {
		
		
	}

	@Override
	public void details() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void address() {
		// TODO Auto-generated method stub
		
	}

	
	


}
