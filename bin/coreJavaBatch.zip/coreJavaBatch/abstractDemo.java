package coreJavaBatch;

public abstract class abstractDemo extends father {
	
	public abstract void name();
	public abstract void address();
	public abstract void mobile();
	public abstract void city();
	
	//+4 abstract methods from bank is here
	
	//concrete method
	public void display() {
		System.out.println("I am in abstract class");
	}

	

}
