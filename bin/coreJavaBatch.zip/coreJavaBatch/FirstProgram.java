package coreJavaBatch;

public class FirstProgram {
	
	
	
	
	//method
	public   void abc (int d,int e) {
		
		System.out.println(d+e);
		
	}
	
	public  static void abcd() {
		
		System.out.println("i am in first abcd");
		
	}
	
	
	

}
