package coreJavaBatch;

public class icicibank implements bank {

	@Override
	public void details() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void address() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int ROI(int a) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void savingaccount() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void current() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void rate() {
		// TODO Auto-generated method stub
		
	}







}
